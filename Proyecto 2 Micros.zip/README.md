# Lumines — CC3086 Programación de Microprocesadores
**Universidad del Valle de Guatemala**

## Compilar

### En Linux / WSL (Ubuntu):
```bash
sudo apt install libncurses-dev
make
./lumines
```

### Con MinGW en Windows (PowerShell):
```bash
pacman -S mingw-w64-x86_64-ncurses
g++ -std=c++17 -o lumines.exe src/lumines.cpp -lncurses -lpthread
./lumines.exe
```

---

## Hilos implementados

| Hilo                 | Función              | Descripción                                         |
|----------------------|----------------------|-----------------------------------------------------|
| threadFallBlock      | Caída del bloque     | Mueve el bloque actual hacia abajo cada tick        |
| threadPlayerInput    | Input del jugador    | Lee teclas con ncurses sin bloquear otros hilos     |
| threadTimeLine       | Línea de tiempo      | Barre el tablero columna a columna y elimina 2x2    |
| threadScore          | Puntaje              | Aplica bonificaciones por cadenas múltiples         |
| threadSpecialBlock   | Bloques especiales   | Detecta `**` y elimina bloques conectados del mismo color |
| threadRender         | Renderizado          | Dibuja el tablero y panel lateral a ~30 FPS         |

## Sincronización

| Mecanismo             | Uso                                                              |
|-----------------------|------------------------------------------------------------------|
| `pthread_mutex_t boardMutex`  | Protege el tablero y el bloque actual                |
| `pthread_mutex_t scoreMutex`  | Protege el puntaje y chainBonus                      |
| `pthread_cond_t blockLanded`  | Notifica al hilo especial cuando aterriza un bloque  |
| `sem_t sweepReady`            | Señala a la línea de tiempo que puede iniciar barrido|
| `pthread_barrier_t startBar`  | Sincroniza el arranque simultáneo de los 6 hilos     |

## Controles

| Tecla      | Acción            |
|------------|-------------------|
| ← →        | Mover bloque      |
| ↓          | Bajar una fila    |
| ↑ / R      | Rotar bloque      |
| ESPACIO    | Drop instantáneo  |
| P          | Pausa / Reanudar  |
| Q          | Salir             |
