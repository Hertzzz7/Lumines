// ============================================================
//  LUMINES  -  CC3086 Programación de Microprocesadores
//  Universidad del Valle de Guatemala
//  Implementación completa con hilos POSIX (Pthreads) en C++
//
//  HILOS INDEPENDIENTES:
//   1. threadFallBlock    - Caída del bloque actual
//   2. threadPlayerInput  - Lectura de teclado del jugador
//   3. threadTimeLine     - Línea de tiempo que barre el tablero
//   4. threadScore        - Cálculo y bonificaciones de puntaje
//   5. threadSpecialBlock - Activación de bloques especiales
//   6. threadRender       - Renderizado en consola (ncurses)
//
//  SINCRONIZACIÓN:
//   - pthread_mutex_t  boardMutex  : protege tablero y bloque actual
//   - pthread_mutex_t  scoreMutex  : protege el puntaje
//   - pthread_cond_t   blockLanded : notifica aterrizaje de bloque
//   - sem_t            sweepReady  : señala a la línea que puede barrer
//   - pthread_barrier_t startBar   : arranque sincronizado de hilos
// ============================================================

#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <ncurses.h>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <unistd.h>
#include <vector>
#include <string>
#include <algorithm>

// ============================================================
//  CONSTANTES
// ============================================================
static const int BROWS       = 16;
static const int BCOLS      = 12;
static const int EMPTY      =  0;
static const int COL_A      =  1;   // bloque claro  []
static const int COL_B      =  2;   // bloque oscuro ##
static const int SPECIAL    =  3;   // bloque especial **

// microsegundos
static const int FALL_SLOW  = 600000;
static const int FALL_FAST  = 220000;
static const int SWEEP_SLOW = 180000;
static const int SWEEP_FAST =  70000;

static const int WIN_SCORE  = 50;   // puntos para ganar
static const int MAX_LIVES  =  3;

// ============================================================
//  ESTRUCTURAS
// ============================================================
struct Piece {
    int color[2][2];
    int row, col;
};

struct ScoreEntry {
    std::string name;
    int score;
};

// ============================================================
//  ESTADO GLOBAL  (variables compartidas entre hilos)
// ============================================================
static int   board[BROWS][BCOLS];
static Piece cur;                    // bloque cayendo
static int   score       = 0;
static int   lives       = MAX_LIVES;
static int   sweepCol    = -1;       // columna visible de la línea (-1 = oculta)
static bool  gameOver    = false;
static bool  gameWon     = false;
static bool  paused      = false;
static int   gameMode    = 1;        // 1=lento 2=rápido
static bool  blockActive = false;    // hay un bloque cayendo actualmente
static int   chainBonus  = 0;        // combos pendientes para el hilo de puntaje

static std::vector<ScoreEntry> highScores;

// ============================================================
//  SINCRONIZACIÓN
// ============================================================
static pthread_mutex_t   boardMutex  = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t   scoreMutex  = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t    blockLanded = PTHREAD_COND_INITIALIZER;
static sem_t             sweepReady;
static pthread_barrier_t startBar;

// ============================================================
//  UTILIDADES DEL TABLERO
// ============================================================
static void clearBoard() {
    memset(board, 0, sizeof(board));
}

static void spawnPiece() {
    cur.row = 0;
    cur.col = BCOLS / 2 - 1;
    for (int r = 0; r < 2; r++)
        for (int c = 0; c < 2; c++) {
            int roll = rand() % 12;
            if (roll == 0) cur.color[r][c] = SPECIAL;
            else           cur.color[r][c] = (rand() % 2) + 1;
        }
}

static bool canPlace(int dr, int dc) {
    for (int r = 0; r < 2; r++)
        for (int c = 0; c < 2; c++) {
            int nr = cur.row + r + dr;
            int nc = cur.col + c + dc;
            if (nr < 0 || nr >= BROWS || nc < 0 || nc >= BCOLS) return false;
            if (board[nr][nc] != EMPTY)                        return false;
        }
    return true;
}

static void placePiece() {
    for (int r = 0; r < 2; r++)
        for (int c = 0; c < 2; c++)
            board[cur.row+r][cur.col+c] = cur.color[r][c];
}

static void rotatePiece() {
    int tmp[2][2];
    tmp[0][0] = cur.color[1][0];
    tmp[0][1] = cur.color[0][0];
    tmp[1][0] = cur.color[1][1];
    tmp[1][1] = cur.color[0][1];
    memcpy(cur.color, tmp, sizeof(tmp));
}

static bool topRowFull() {
    for (int c = 0; c < BCOLS; c++)
        if (board[0][c] != EMPTY) return true;
    return false;
}

// Aplica gravedad: bloques caen a posiciones vacías
static void applyGravity() {
    for (int c = 0; c < BCOLS; c++) {
        int w = BROWS - 1;
        for (int r = BROWS - 1; r >= 0; r--) {
            if (board[r][c] != EMPTY) {
                board[w][c] = board[r][c];
                if (w != r) board[r][c] = EMPTY;
                w--;
            }
        }
        while (w >= 0) board[w--][c] = EMPTY;
    }
}

// Detecta y elimina cuadrados 2x2 del mismo color
// Retorna cantidad de cuadrados eliminados
static int clearSquares() {
    bool mark[BROWS][BCOLS];
    memset(mark, false, sizeof(mark));
    int found = 0;

    for (int r = 0; r < BROWS - 1; r++) {
        for (int c = 0; c < BCOLS - 1; c++) {
            int col = board[r][c];
            if (col == EMPTY || col == SPECIAL) continue;
            if (board[r][c]     == col &&
                board[r][c+1]   == col &&
                board[r+1][c]   == col &&
                board[r+1][c+1] == col)
            {
                mark[r][c] = mark[r][c+1] =
                mark[r+1][c] = mark[r+1][c+1] = true;
                found++;
            }
        }
    }
    for (int r = 0; r < BROWS; r++)
        for (int c = 0; c < BCOLS; c++)
            if (mark[r][c]) board[r][c] = EMPTY;
    return found;
}

// BFS: elimina todos los bloques conectados del mismo color
static int clearConnected(int sr, int sc) {
    int target = board[sr][sc];
    if (target == EMPTY) return 0;
    int removed = 0;
    std::vector<std::pair<int,int>> q;
    q.push_back({sr, sc});
    board[sr][sc] = EMPTY;
    int dr[] = {-1,1,0,0};
    int dc[] = {0,0,-1,1};
    size_t head = 0;
    while (head < q.size()) {
        auto [r,c] = q[head++];
        removed++;
        for (int i = 0; i < 4; i++) {
            int nr = r+dr[i], nc = c+dc[i];
            if (nr>=0 && nr<BROWS && nc>=0 && nc<BCOLS && board[nr][nc]==target) {
                board[nr][nc] = EMPTY;
                q.push_back({nr, nc});
            }
        }
    }
    return removed;
}

// ============================================================
//  HILO 1 — Caída del bloque
// ============================================================
static void* threadFallBlock(void*) {
    pthread_barrier_wait(&startBar);
    int speed = (gameMode == 1) ? FALL_SLOW : FALL_FAST;

    while (!gameOver) {
        if (paused) { usleep(100000); continue; }
        usleep(speed);

        pthread_mutex_lock(&boardMutex);

        if (!blockActive) { pthread_mutex_unlock(&boardMutex); continue; }

        if (canPlace(1, 0)) {
            cur.row++;
        } else {
            // Aterrizar
            placePiece();
            blockActive = false;

            // Señal a la línea de tiempo
            sem_post(&sweepReady);
            // Señal al hilo de bloques especiales
            pthread_cond_broadcast(&blockLanded);

            // Verificar derrota
            if (topRowFull()) {
                lives--;
                if (lives <= 0) {
                    gameOver = true;
                    pthread_mutex_unlock(&boardMutex);
                    break;
                }
                clearBoard();
            }

            // Nuevo bloque
            spawnPiece();
            blockActive = true;

            // Verificar victoria
            pthread_mutex_lock(&scoreMutex);
            if (score >= WIN_SCORE) { gameWon = true; gameOver = true; }
            pthread_mutex_unlock(&scoreMutex);
        }

        pthread_mutex_unlock(&boardMutex);
    }

    // Despertar hilos bloqueados para que puedan terminar
    sem_post(&sweepReady);
    pthread_cond_broadcast(&blockLanded);
    return nullptr;
}

// ============================================================
//  HILO 2 — Input del jugador
// ============================================================
static void* threadPlayerInput(void*) {
    pthread_barrier_wait(&startBar);

    while (!gameOver) {
        int ch = getch();
        if (ch == ERR) { usleep(20000); continue; }

        if (ch == 'p' || ch == 'P') { paused = !paused; continue; }
        if (ch == 'q' || ch == 'Q') { gameOver = true;  continue; }
        if (paused) continue;

        pthread_mutex_lock(&boardMutex);
        if (blockActive) {
            switch (ch) {
                case KEY_LEFT:  if (canPlace(0,-1)) cur.col--; break;
                case KEY_RIGHT: if (canPlace(0, 1)) cur.col++; break;
                case KEY_DOWN:  if (canPlace(1, 0)) cur.row++; break;
                case KEY_UP: case 'r': case 'R': rotatePiece(); break;
                case ' ':   // Hard drop
                    while (canPlace(1,0)) cur.row++;
                    break;
            }
        }
        pthread_mutex_unlock(&boardMutex);
    }
    return nullptr;
}

// ============================================================
//  HILO 3 — Línea de tiempo
// ============================================================
static void* threadTimeLine(void*) {
    pthread_barrier_wait(&startBar);
    int speed = (gameMode == 1) ? SWEEP_SLOW : SWEEP_FAST;

    while (!gameOver) {
        sem_wait(&sweepReady);
        if (gameOver) break;

        // Barrer de izquierda a derecha
        int totalCleared = 0;
        for (int col = 0; col < BCOLS && !gameOver; col++) {
            usleep(speed);

            pthread_mutex_lock(&boardMutex);
            sweepCol = col;

            int cleared = clearSquares();
            if (cleared > 0) {
                applyGravity();
                totalCleared += cleared;

                // Bonus por cadena: si ya había limpiado antes en este barrido
                if (totalCleared > cleared) {
                    pthread_mutex_lock(&scoreMutex);
                    chainBonus += 5;
                    pthread_mutex_unlock(&scoreMutex);
                }

                pthread_mutex_lock(&scoreMutex);
                score += cleared * 10;
                pthread_mutex_unlock(&scoreMutex);
            }

            pthread_mutex_unlock(&boardMutex);
        }

        pthread_mutex_lock(&boardMutex);
        sweepCol = -1;
        pthread_mutex_unlock(&boardMutex);
    }
    return nullptr;
}

// ============================================================
//  HILO 4 — Puntaje y bonificaciones
// ============================================================
static void* threadScore(void*) {
    pthread_barrier_wait(&startBar);

    while (!gameOver) {
        usleep(80000);

        pthread_mutex_lock(&scoreMutex);
        if (chainBonus > 0) {
            score += chainBonus;
            chainBonus = 0;
        }
        // Verificar victoria
        if (score >= WIN_SCORE && !gameOver) {
            gameWon  = true;
            gameOver = true;
        }
        pthread_mutex_unlock(&scoreMutex);
    }
    return nullptr;
}

// ============================================================
//  HILO 5 — Bloques especiales
// ============================================================
static void* threadSpecialBlock(void*) {
    pthread_barrier_wait(&startBar);

    while (!gameOver) {
        pthread_mutex_lock(&boardMutex);
        pthread_cond_wait(&blockLanded, &boardMutex);

        if (gameOver) { pthread_mutex_unlock(&boardMutex); break; }

        // Buscar celdas SPECIAL en el tablero
        for (int r = 0; r < BROWS && !gameOver; r++) {
            for (int c = 0; c < BCOLS && !gameOver; c++) {
                if (board[r][c] != SPECIAL) continue;

                // Encontrar color dominante adyacente
                int adjColor = -1;
                int dr[] = {-1,1,0,0};
                int dc[] = {0,0,-1,1};
                for (int i = 0; i < 4; i++) {
                    int nr = r+dr[i], nc = c+dc[i];
                    if (nr>=0&&nr<BROWS&&nc>=0&&nc<BCOLS &&
                        board[nr][nc]!=EMPTY && board[nr][nc]!=SPECIAL) {
                        adjColor = board[nr][nc];
                        break;
                    }
                }
                if (adjColor == -1) continue;

                // Convertir SPECIAL en ese color y limpiar conectados
                board[r][c] = adjColor;
                int removed = clearConnected(r, c);
                applyGravity();

                pthread_mutex_lock(&scoreMutex);
                score += removed * 5 + 15;
                pthread_mutex_unlock(&scoreMutex);
            }
        }

        pthread_mutex_unlock(&boardMutex);
    }
    return nullptr;
}

// ============================================================
//  VENTANAS NCURSES  (variables globales para el hilo render)
// ============================================================
static WINDOW* wBoard = nullptr;
static WINDOW* wSide  = nullptr;

// ============================================================
//  HILO 6 — Render
// ============================================================
static void* threadRender(void*) {
    pthread_barrier_wait(&startBar);

    while (!gameOver) {
        usleep(33000);  // ~30 FPS

        pthread_mutex_lock(&boardMutex);

        werase(wBoard);
        werase(wSide);
        box(wBoard, 0, 0);
        box(wSide,  0, 0);

        // — Tablero —
        for (int r = 0; r < BROWS; r++) {
            for (int c = 0; c < BCOLS; c++) {
                wmove(wBoard, r+1, c*2+1);

                // Línea de tiempo
                if (c == sweepCol) {
                    wattron(wBoard, A_BOLD | A_REVERSE);
                    waddstr(wBoard, "  ");
                    wattroff(wBoard, A_BOLD | A_REVERSE);
                    continue;
                }

                switch (board[r][c]) {
                    case COL_A:   wattron(wBoard,A_BOLD);  waddstr(wBoard,"[]"); wattroff(wBoard,A_BOLD); break;
                    case COL_B:   waddstr(wBoard, "##"); break;
                    case SPECIAL: wattron(wBoard,A_BLINK); waddstr(wBoard,"**"); wattroff(wBoard,A_BLINK); break;
                    default:      waddstr(wBoard, "  "); break;
                }
            }
        }

        // — Bloque cayendo —
        if (blockActive) {
            for (int r = 0; r < 2; r++) {
                for (int c = 0; c < 2; c++) {
                    int pr = cur.row+r, pc = cur.col+c;
                    if (pr<0||pr>=BROWS||pc<0||pc>=BCOLS) continue;
                    wmove(wBoard, pr+1, pc*2+1);
                    wattron(wBoard, A_REVERSE);
                    switch (cur.color[r][c]) {
                        case COL_A:   waddstr(wBoard, "[]"); break;
                        case COL_B:   waddstr(wBoard, "##"); break;
                        case SPECIAL: waddstr(wBoard, "**"); break;
                    }
                    wattroff(wBoard, A_REVERSE);
                }
            }
        }

        // — Panel lateral —
        mvwprintw(wSide,  1, 2, "  LUMINES");
        mvwprintw(wSide,  2, 2, "──────────────────");
        mvwprintw(wSide,  3, 2, "Puntaje : %d / %d", score, WIN_SCORE);
        mvwprintw(wSide,  4, 2, "Vidas   : ");
        for (int i = 0; i < lives; i++) waddstr(wSide, "♥ ");
        mvwprintw(wSide,  5, 2, "Modo    : %s", gameMode==1 ? "LENTO" : "RAPIDO");
        mvwprintw(wSide,  7, 2, "CONTROLES");
        mvwprintw(wSide,  8, 2, "← →  Mover");
        mvwprintw(wSide,  9, 2, "↓    Bajar");
        mvwprintw(wSide, 10, 2, "↑/R  Rotar");
        mvwprintw(wSide, 11, 2, "SPC  Drop rapido");
        mvwprintw(wSide, 12, 2, "P    Pausa");
        mvwprintw(wSide, 13, 2, "Q    Salir");
        mvwprintw(wSide, 15, 2, "LEYENDA");
        mvwprintw(wSide, 16, 2, "[]  Bloque A");
        mvwprintw(wSide, 17, 2, "##  Bloque B");
        mvwprintw(wSide, 18, 2, "**  Especial");
        mvwprintw(wSide, 19, 2, "    Linea T.");

        // Progreso hacia victoria
        int pct = std::min(100, score * 100 / WIN_SCORE);
        mvwprintw(wSide, 21, 2, "Meta [");
        for (int i = 0; i < 14; i++)
            waddch(wSide, i < pct*14/100 ? '#' : '-');
        waddstr(wSide, "]");
        mvwprintw(wSide, 22, 2, "     %d%%", pct);

        if (paused) {
            wattron(wSide, A_BOLD | A_REVERSE);
            mvwprintw(wSide, 24, 2, "  ** PAUSA **  ");
            wattroff(wSide, A_BOLD | A_REVERSE);
        }

        wrefresh(wBoard);
        wrefresh(wSide);

        pthread_mutex_unlock(&boardMutex);
    }
    return nullptr;
}

// ============================================================
//  PANTALLA: MENÚ PRINCIPAL
// ============================================================
static int showMenu() {
    clear();
    int my = LINES/2 - 8, mx = COLS/2 - 16;
    if (my < 0) my = 0;
    if (mx < 0) mx = 0;

    mvprintw(my+0, mx, "╔══════════════════════════════╗");
    mvprintw(my+1, mx, "║                              ║");
    mvprintw(my+2, mx, "║    L  U  M  I  N  E  S       ║");
    mvprintw(my+3, mx, "║    CC3086 - UVG  2025        ║");
    mvprintw(my+4, mx, "║                              ║");
    mvprintw(my+5, mx, "╚══════════════════════════════╝");
    mvprintw(my+7, mx, "  [1]  Modo Lento");
    mvprintw(my+8, mx, "  [2]  Modo Rapido");
    mvprintw(my+9, mx, "  [3]  Instrucciones");
    mvprintw(my+10,mx, "  [4]  Puntajes destacados");
    mvprintw(my+11,mx, "  [5]  Salir");
    mvprintw(my+13,mx, "  Opcion: ");
    refresh();
    nodelay(stdscr, FALSE);
    int ch = getch();
    nodelay(stdscr, TRUE);
    return ch - '0';
}

// ============================================================
//  PANTALLA: INSTRUCCIONES
// ============================================================
static void showInstructions() {
    clear();
    mvprintw(1,  2, "╔═══════════════════════════════════════╗");
    mvprintw(2,  2, "║           INSTRUCCIONES               ║");
    mvprintw(3,  2, "╚═══════════════════════════════════════╝");
    mvprintw(5,  2, "Lumines es un puzzle de bloques 2x2.");
    mvprintw(6,  2, "Coloca bloques para formar cuadrados 2x2");
    mvprintw(7,  2, "del mismo color. La linea de tiempo barre");
    mvprintw(8,  2, "el tablero y elimina los cuadrados validos.");
    mvprintw(10, 2, "OBJETIVO:");
    mvprintw(11, 2, "  Alcanza %d puntos para GANAR.", WIN_SCORE);
    mvprintw(12, 2, "  Tienes %d vidas. Si los bloques llegan", MAX_LIVES);
    mvprintw(13, 2, "  arriba pierdes una vida.");
    mvprintw(15, 2, "CONTROLES:");
    mvprintw(16, 2, "  Flecha Izq/Der  ->  Mover bloque");
    mvprintw(17, 2, "  Flecha Abajo    ->  Bajar una fila");
    mvprintw(18, 2, "  Flecha Arriba/R ->  Rotar bloque");
    mvprintw(19, 2, "  ESPACIO         ->  Drop instantaneo");
    mvprintw(20, 2, "  P               ->  Pausa / Reanudar");
    mvprintw(21, 2, "  Q               ->  Salir");
    mvprintw(23, 2, "PUNTAJE:");
    mvprintw(24, 2, "  +10 por cada cuadrado 2x2 eliminado");
    mvprintw(25, 2, "  +5  bonus por cadenas en un barrido");
    mvprintw(26, 2, "  +15 bonus por bloque especial (**)");
    mvprintw(28, 2, "Presiona cualquier tecla para volver...");
    refresh();
    nodelay(stdscr, FALSE);
    getch();
    nodelay(stdscr, TRUE);
}

// ============================================================
//  PANTALLA: PUNTAJES DESTACADOS
// ============================================================
static void showHighScores() {
    clear();
    mvprintw(1, 2, "╔══════════════════════════════╗");
    mvprintw(2, 2, "║      PUNTAJES DESTACADOS     ║");
    mvprintw(3, 2, "╚══════════════════════════════╝");

    if (highScores.empty()) {
        mvprintw(5, 2, "  Aun no hay puntajes registrados.");
    } else {
        mvprintw(5, 2, "  #   Nombre          Puntaje");
        mvprintw(6, 2, "  ─────────────────────────────");
        int limit = std::min((int)highScores.size(), 10);
        for (int i = 0; i < limit; i++) {
            mvprintw(7+i, 2, "  %d.  %-14s  %d",
                i+1,
                highScores[i].name.substr(0,14).c_str(),
                highScores[i].score);
        }
    }

    mvprintw(20, 2, "Presiona cualquier tecla para volver...");
    refresh();
    nodelay(stdscr, FALSE);
    getch();
    nodelay(stdscr, TRUE);
}

// ============================================================
//  PANTALLA: FIN DE JUEGO
// ============================================================
static void showEndScreen() {
    nodelay(stdscr, FALSE);
    clear();

    if (gameWon) {
        mvprintw(4, 4, "╔══════════════════════════════╗");
        mvprintw(5, 4, "║      *** GANASTE! ***        ║");
        mvprintw(6, 4, "╚══════════════════════════════╝");
    } else {
        mvprintw(4, 4, "╔══════════════════════════════╗");
        mvprintw(5, 4, "║        GAME  OVER            ║");
        mvprintw(6, 4, "╚══════════════════════════════╝");
    }

    mvprintw(8,  4, "  Puntaje final : %d", score);
    mvprintw(9,  4, "  Vidas restantes: %d", std::max(0, lives));

    // Registrar puntaje si es relevante
    mvprintw(11, 4, "  Ingresa tu nombre (max 12 chars):");
    mvprintw(12, 4, "  > ");
    echo(); curs_set(1);
    char nameBuf[32] = {};
    getnstr(nameBuf, 12);
    noecho(); curs_set(0);

    if (strlen(nameBuf) > 0) {
        highScores.push_back({std::string(nameBuf), score});
        // Ordenar de mayor a menor
        std::sort(highScores.begin(), highScores.end(),
            [](const ScoreEntry& a, const ScoreEntry& b){ return a.score > b.score; });
        if (highScores.size() > 10) highScores.resize(10);
    }

    mvprintw(15, 4, "  [R] Jugar de nuevo");
    mvprintw(16, 4, "  [Q] Volver al menu");
    refresh();

    int ch = 0;
    while (ch != 'r' && ch != 'R' && ch != 'q' && ch != 'Q')
        ch = getch();

    nodelay(stdscr, TRUE);
    // Retornar 1 = jugar de nuevo, 0 = menu
    // Usamos variable global simple
    if (ch == 'q' || ch == 'Q') gameWon = false; // señal: ir a menú
}

// ============================================================
//  LANZAR UNA PARTIDA
// ============================================================
static bool playGame(int mode) {
    gameMode    = mode;
    gameOver    = false;
    gameWon     = false;
    paused      = false;
    score       = 0;
    lives       = MAX_LIVES;
    sweepCol    = -1;
    chainBonus  = 0;
    blockActive = true;

    clearBoard();
    spawnPiece();

    // Crear ventanas de ncurses
    int boardW = BCOLS*2 + 2;
    int boardH = BROWS + 2;
    int startX = (COLS/2) - (boardW/2) - 12;
    if (startX < 0) startX = 0;

    wBoard = newwin(boardH, boardW, 1, startX);
    wSide  = newwin(boardH, 26,    1, startX + boardW + 2);

    sem_init(&sweepReady, 0, 0);
    pthread_barrier_init(&startBar, nullptr, 7); // 6 hilos + main

    pthread_t tFall, tInput, tLine, tScoreT, tSpecial, tRender;
    pthread_create(&tFall,    nullptr, threadFallBlock,   nullptr);
    pthread_create(&tInput,   nullptr, threadPlayerInput, nullptr);
    pthread_create(&tLine,    nullptr, threadTimeLine,    nullptr);
    pthread_create(&tScoreT,  nullptr, threadScore,       nullptr);
    pthread_create(&tSpecial, nullptr, threadSpecialBlock,nullptr);
    pthread_create(&tRender,  nullptr, threadRender,      nullptr);

    pthread_barrier_wait(&startBar);  // main también participa en la barrera

    pthread_join(tFall,    nullptr);
    pthread_join(tInput,   nullptr);
    pthread_join(tLine,    nullptr);
    pthread_join(tScoreT,  nullptr);
    pthread_join(tSpecial, nullptr);
    pthread_join(tRender,  nullptr);

    sem_destroy(&sweepReady);
    pthread_barrier_destroy(&startBar);

    delwin(wBoard); wBoard = nullptr;
    delwin(wSide);  wSide  = nullptr;

    showEndScreen();

    // Si gameWon sigue true después de showEndScreen = eligió menú
    // Si eligió jugar de nuevo = volver a llamar playGame
    // Usamos un truco: showEndScreen deja gameWon=false cuando elige Q
    return gameWon; // true = volver a jugar mismo modo, false = ir a menú
}

// ============================================================
//  MAIN
// ============================================================
int main() {
    srand((unsigned)time(nullptr));

    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    nodelay(stdscr, TRUE);
    curs_set(0);

    bool running = true;
    while (running) {
        int opt = showMenu();
        switch (opt) {
            case 1:
                while (playGame(1));  // juega modo lento hasta que elija menú
                break;
            case 2:
                while (playGame(2));  // juega modo rápido
                break;
            case 3:
                showInstructions();
                break;
            case 4:
                showHighScores();
                break;
            case 5:
                running = false;
                break;
            default:
                break;
        }
    }

    endwin();
    std::cout << "\n¡Gracias por jugar Lumines!\n";
    return 0;
}
